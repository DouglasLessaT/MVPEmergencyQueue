package douglas.unisales.EmergencyQueueApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmergencyQueueApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
