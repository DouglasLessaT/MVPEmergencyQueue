package douglas.pie.com.hospitalbed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalbedApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalbedApplication.class, args);
	}

}
